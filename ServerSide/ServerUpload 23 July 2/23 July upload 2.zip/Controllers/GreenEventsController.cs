﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Diagnostics;
using System.Net.Http;
using System.Web.Http;
using DATA;
using WebApplication2check.DTO;
using NLog;
using System.Globalization;

namespace WebApplication2check.Controllers
{
    public class GreenEventsController : ApiController
    {

        private static Logger logger = LogManager.GetCurrentClassLogger();
        igroup196_DbContextNew1 db = new igroup196_DbContextNew1();

        [HttpGet]
        [Route("api/GreenEvents/get")]
        public IHttpActionResult Get()
        {
            igroup196_DbContextNew1 db = new igroup196_DbContextNew1();
            try
            {
                var events = db.GreenEvents.Select(x => new GreenEventsDTO()
                {
                    eventSerialNum = x.eventSerialNum,
                    event_name = x.event_name,
                    event_address = x.event_address,
                    event_startdate = x.event_startdate,
                    event_enddate = x.event_enddate,
                    isEventActive = x.isEventActive,
                    employee_id = x.employee_id,
                    clientNumber = x.clientNumber,
                    event_notes = x.event_notes

                });

                return Ok(events);
            }
            catch (Exception)
            {
                logger.Error("Cant fetch Event Data");
                return BadRequest("Cant upload Event List");
            }



        }


        [HttpGet]
        [Route("api/GreenEvents/getMonthlyEventCounts")]
        public IHttpActionResult GetMonthlyEventCounts()
        {
            igroup196_DbContextNew1 db = new igroup196_DbContextNew1();
            try
            {
                var events = db.GreenEvents
                    .Where(x => x.event_startdate.HasValue)  // Filter out nulls
                    .GroupBy(x => x.event_startdate.Value.Month)
                    .ToList()  // ToList here to execute the SQL part of the query
                    .Select(g => new
                    {
                        Month = CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(g.Key),
                        Events = g.Count()
                    })
                    .ToList();

                return Ok(events);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.ToString());
                logger.Error("Can't fetch monthly event counts");
                return BadRequest("Can't fetch monthly event counts");
            }
        }



        [HttpGet]
        [Route("api/GreenEvents/getMonthlyEventCountsbyYear")]
        public IHttpActionResult GetMonthlyEventCountsByYear()
        {
            igroup196_DbContextNew1 db = new igroup196_DbContextNew1();
            try
            {
                var events = db.GreenEvents
                    .Where(x => x.event_startdate.HasValue)  // Filter out nulls
                    .GroupBy(x => new { x.event_startdate.Value.Year, x.event_startdate.Value.Month })
                    .ToList()  // ToList here to execute the SQL part of the query
                    .Select(g => new
                    {
                        Year = g.Key.Year,
                        Month = CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(g.Key.Month),
                        Events = g.Count()
                    })
                    .ToList();

                return Ok(events);
            }
            catch (Exception ex)
            {
                
                logger.Error("Can't fetch monthly event counts");
                return BadRequest("Can't fetch monthly event counts");
            }
        }



        [HttpGet]
        [Route("api/GreenEvents/GetWeeksEvents")]
        public IHttpActionResult GetWeeksEvents()
        {
            igroup196_DbContextNew1 db = new igroup196_DbContextNew1();
            try
            {
                var today = DateTime.Today;
                var nextWeek = today.AddDays(7);

                var weeksEvents = db.GreenEvents
                    .Where(x => x.event_startdate >= today && x.event_startdate <= nextWeek) // Retrieve events with start date within the next week
                    .OrderBy(x => x.event_startdate) // Order events by start date in ascending order
                    .Select(x => new GreenEventsDTO() // Create a DTO for each event
            {
                        eventSerialNum = x.eventSerialNum,
                        event_name = x.event_name,
                        event_address = x.event_address,
                        event_startdate = x.event_startdate,
                        event_enddate = x.event_enddate,
                        isEventActive = x.isEventActive,
                        employee_id = x.employee_id,
                        clientNumber = x.clientNumber,
                        event_notes = x.event_notes
                    })
                    .ToList(); // Convert to list

                if (weeksEvents.Any())
                {
                    return Ok(weeksEvents);
                }
                else
                {
                    return NotFound(); // Return 404 if no events found
                }
            }
            catch (Exception)
            {
                logger.Error("Unable to fetch week's event data.");
                return BadRequest("Unable to retrieve week's events.");
            }
        }


        [HttpGet]
        [Route("api/GreenEvents/GetClosestEvent")]
        public IHttpActionResult GetClosestEvent()
        {
            igroup196_DbContextNew1 db = new igroup196_DbContextNew1();
            try
            {
                var closestEvent = db.GreenEvents
                    .Where(x => x.event_startdate >= DateTime.Today) // Retrieve events with start date greater than or equal to today
                    .OrderBy(x => x.event_startdate) // Order events by start date in ascending order
                    .FirstOrDefault(); // Get the first event (closest event)

                if (closestEvent != null)
                {
                    var closestEventDto = new GreenEventsDTO()
                    {
                        eventSerialNum = closestEvent.eventSerialNum,
                        event_name = closestEvent.event_name,
                        event_address = closestEvent.event_address,
                        event_startdate = closestEvent.event_startdate,
                        event_enddate = closestEvent.event_enddate,
                        isEventActive = closestEvent.isEventActive,
                        employee_id = closestEvent.employee_id,
                        clientNumber = closestEvent.clientNumber,
                        event_notes = closestEvent.event_notes
                    };

                    return Ok(closestEventDto);
                }
                else
                {
                    return NotFound(); // Return 404 if no events found
                }
            }
            catch (Exception)
            {
                logger.Error("Unable to fetch closest event data.");
                return BadRequest("Unable to retrieve closest event.");
            }
        }



        [HttpGet]
        [Route("api/GreenEvents/GetEventWithItems/{eventSerialNum}")]
        public IHttpActionResult GetEventWithItems(int eventSerialNum)

        {
            try
            {
                // Fetch the event
                var eventDetail = db.GreenEvents.Where(x => x.eventSerialNum == eventSerialNum)
                .Select(e => new InventoryAllocationRequestDTO()
                {
                    eventSerialNum = e.eventSerialNum,
                    event_name = e.event_name,
                    event_address = e.event_address,
                    event_startdate = e.event_startdate,
                    event_enddate = e.event_enddate,
                    IsEventActive = e.isEventActive,
                    employee_id = e.employee_id,
                    clientNumber = e.clientNumber,
                    event_notes = e.event_notes
                }).FirstOrDefault();

                if (eventDetail == null)
                {
                    return NotFound();
                }

                // Fetch all the inventory items for this event
                var items = db.EventInventoryAllocation
                .Where(x => x.eventSerialNum == eventSerialNum)
                .Join(db.InventoryItems, eia => eia.itemSerialNum, ii => ii.itemSerialNum,
                   (eia, ii) => new ItemAllocationDTO()
                    {
                       itemName=ii.itemName,
                      itemSerialNum = ii.itemSerialNum,
                      itemAmount = eia.allocated_quantity
                          })
                     .ToList();

                // Add the items to the eventDetail DTO
                eventDetail.ItemAllocations = items;

                return Ok(eventDetail);
            }
            catch (Exception ex)
            {
                logger.Error(ex, "Error fetching event with inventory items");
                return BadRequest("Can't fetch event with inventory items");
            }
        }


        //[HttpGet]
        //[Route("api/GreenEvents/MostProfitablePlant")]
        //public IHttpActionResult GetMostProfitablePlant()
        //{
        //    var sixMonthsAgo = DateTime.Now.AddMonths(-6);

        //    var result = db.GreenEvents
        //        .Where(e => e.event_enddate > sixMonthsAgo)
        //        .Join(db.EventInventoryAllocation,
        //            e => e.eventSerialNum,
        //            ea => ea.itemSerialNum,
        //            (e, ea) => new { Event = e, EventInventoryAllocation = ea })
        //        .Join(db.InventoryItems,
        //            e_ea => e_ea.EventInventoryAllocation.itemSerialNum,
        //            i => i.itemSerialNum,
        //            (e_ea, i) => new { EventAllocation = e_ea, InventoryItem = i })
        //        .GroupBy(ea_i => new { ea_i.InventoryItem.itemSerialNum, ea_i.InventoryItem.itemName })
        //        .Select(g => new
        //        {
        //            PlantId = g.Key.itemSerialNum,
        //            PlantName = g.Key.itemName,
        //            TotalProfit = g.Sum(ea_i => ea_i.InventoryItem.price - ea_i.InventoryItem.buyingPrice),
        //            TimesRented = g.Count()
        //        })
        //        .OrderByDescending(g => g.TotalProfit)
        //        .ThenByDescending(g => g.TimesRented)
        //        .FirstOrDefault();

        //    return Ok(result);
        //}

        //[HttpGet]
        //[Route("api/GreenEvents/MostProfitablePlant")]
        //public IHttpActionResult GetMostProfitablePlant()
        //{
        //    var sixMonthsAgo = DateTime.Now.AddMonths(-6);

        //    var result = db.GreenEvents
        //        .Where(e => e.event_enddate > sixMonthsAgo)
        //        .Join(db.EventInventoryAllocation,
        //            e => e.eventSerialNum,
        //            ea => ea.itemSerialNum,
        //            (e, ea) => new { Event = e, EventAllocation = ea })
        //        .Join(db.InventoryItems,
        //            e_ea => e_ea.EventAllocation.itemSerialNum,
        //            i => i.itemSerialNum,
        //            (e_ea, i) => new { EventAllocation = e_ea, InventoryItem = i })
        //        .GroupBy(ea_i => new { ea_i.InventoryItem.itemSerialNum, ea_i.InventoryItem.itemName })
        //        .Select(g => new
        //        {
        //            PlantId = g.Key.itemSerialNum,
        //            PlantName = g.Key.itemName,
        //            TotalProfit = g.Sum(ea_i =>
        //                (ea_i.InventoryItem.price - ea_i.InventoryItem.buyingPrice)
        //                * ea_i.EventAllocation.EventAllocation.allocated_quantity
        //                * ((ea_i.EventAllocation.Event.event_enddate.HasValue && ea_i.EventAllocation.Event.event_startdate.HasValue)
        //                ? (ea_i.EventAllocation.Event.event_enddate.Value - ea_i.EventAllocation.Event.event_startdate.Value).Days + 1
        //                    : 0)
        //            ),
        //            TimesRented = g.Count()
        //        })
        //        .OrderByDescending(g => g.TotalProfit)
        //        .ThenByDescending(g => g.TimesRented)
        //        .FirstOrDefault();

        //    return Ok(result);
        //}


        [HttpGet]
        [Route("api/GreenEvents/MostProfitablePlant")]
        public IHttpActionResult GetMostProfitablePlant()
        {
            var sixMonthsAgo = DateTime.Now.AddMonths(-6);

            var data = db.GreenEvents
                .Where(e => e.event_enddate > sixMonthsAgo)
                .Join(db.EventInventoryAllocation,
                    e => e.eventSerialNum,
                    ea => ea.eventSerialNum,
                    (e, ea) => new { Event = e, EventAllocation = ea }) // Renamed from EventInventoryAllocation to EventAllocation for clarity
                .Join(db.InventoryItems,
                    e_ea => e_ea.EventAllocation.itemSerialNum,
                    i => i.itemSerialNum,
                    (e_ea, i) => new { EventAllocation = e_ea, InventoryItem = i })
                .ToList(); // Fetch data from database

            var result = data
                .Select(ea_i => new
                {
                    Item = ea_i.InventoryItem,
                    DaysRented = ((ea_i.EventAllocation.Event.event_enddate ?? DateTime.Now) - (ea_i.EventAllocation.Event.event_startdate ?? DateTime.Now)).Days,
                    AllocatedQuantity = ea_i.EventAllocation.EventAllocation.allocated_quantity // Added this line to fetch the allocated quantity from the EventInventoryAllocation table
        })
                .GroupBy(e => new { e.Item.itemSerialNum, e.Item.itemName })
                .Select(g => new
                {
                    PlantId = g.Key.itemSerialNum,
                    PlantName = g.Key.itemName,
                    TotalProfit = g.Sum(e => e.DaysRented * e.AllocatedQuantity * (e.Item.price - e.Item.buyingPrice)), // Modified this line to multiply the profit by the quantity
            TimesRented = g.Count()
                })
                .OrderByDescending(g => g.TotalProfit)
                .ThenByDescending(g => g.TimesRented)
                .FirstOrDefault();

            return Ok(result);
        }



        [HttpGet]
        [Route("api/GreenEvents/ThreeMostProfitablePlants")]
        public IHttpActionResult GetThreeMostProfitablePlants()
        {
            var sixMonthsAgo = DateTime.Now.AddMonths(-6);


            var data = db.GreenEvents
               .Where(e => e.event_enddate > sixMonthsAgo)
               .Join(db.EventInventoryAllocation,
                   e => e.eventSerialNum,
                   ea => ea.eventSerialNum,
                   (e, ea) => new { Event = e, EventAllocation = ea }) // Renamed from EventInventoryAllocation to EventAllocation for clarity
               .Join(db.InventoryItems,
                   e_ea => e_ea.EventAllocation.itemSerialNum,
                   i => i.itemSerialNum,
                   (e_ea, i) => new { EventAllocation = e_ea, InventoryItem = i })
               .ToList(); // Fetch data from database

            var result = data
         .Select(ea_i => new
         {
             Item = ea_i.InventoryItem,
             DaysRented = ((ea_i.EventAllocation.Event.event_enddate ?? DateTime.Now) - (ea_i.EventAllocation.Event.event_startdate ?? DateTime.Now)).Days,
             AllocatedQuantity = ea_i.EventAllocation.EventAllocation.allocated_quantity
         })
         .GroupBy(e => new { e.Item.itemSerialNum, e.Item.itemName })
         .Select(g => new
         {
             PlantId = g.Key.itemSerialNum,
             PlantName = g.Key.itemName,
             PlantPicture = g.First().Item.itemPicture, // Access itemPicture from the first item in each group
            TotalProfit = g.Sum(e => e.DaysRented * e.AllocatedQuantity * (e.Item.price - e.Item.buyingPrice)),
             TimesRented = g.Count()
         })
         .OrderByDescending(g => g.TotalProfit)
         .ThenByDescending(g => g.TimesRented)
         .Take(3);

            return Ok(result);
        }



        [HttpGet]
        [Route("api/GreenEvents/ThreeMostUnprofitablePlants")]
        public IHttpActionResult GetThreeMostUnprofitablePlants()
        {
            var sixMonthsAgo = DateTime.Now.AddMonths(-6);


            var data = db.GreenEvents
               .Where(e => e.event_enddate > sixMonthsAgo)
               .Join(db.EventInventoryAllocation,
                   e => e.eventSerialNum,
                   ea => ea.eventSerialNum,
                   (e, ea) => new { Event = e, EventAllocation = ea }) // Renamed from EventInventoryAllocation to EventAllocation for clarity
               .Join(db.InventoryItems,
                   e_ea => e_ea.EventAllocation.itemSerialNum,
                   i => i.itemSerialNum,
                   (e_ea, i) => new { EventAllocation = e_ea, InventoryItem = i })
               .ToList(); // Fetch data from database

            var result = data
                .Select(ea_i => new
                {
                    Item = ea_i.InventoryItem,
                    DaysRented = ((ea_i.EventAllocation.Event.event_enddate ?? DateTime.Now) - (ea_i.EventAllocation.Event.event_startdate ?? DateTime.Now)).Days,
                    AllocatedQuantity = ea_i.EventAllocation.EventAllocation.allocated_quantity
                })
                .GroupBy(e => new { e.Item.itemSerialNum, e.Item.itemName })
                .Select(g => new
                {
                    PlantId = g.Key.itemSerialNum,
                    PlantName = g.Key.itemName,
                    PlantPicture = g.First().Item.itemPicture, // Access itemPicture from the first item in each group
            TotalProfit = g.Sum(e => e.DaysRented * e.AllocatedQuantity * (e.Item.price - e.Item.buyingPrice)),
                    TimesRented = g.Count()
                })
                .OrderBy(g => g.TotalProfit)
                .ThenBy(g => g.TimesRented)
                .Take(3);

            return Ok(result);
        }




        // POST: api/GreenEvents
        [HttpPost]
        [Route("api/GreenEvents/post")]
        public IHttpActionResult Post([FromBody] GreenEventsDTO events)
        {
            igroup196_DbContextNew1 db = new igroup196_DbContextNew1();
            try
            {

                var newEvent = new GreenEvents
                {

                    eventSerialNum = events.eventSerialNum,
                    event_name = events.event_name,
                    event_address = events.event_address,
                    event_startdate = events.event_startdate,
                    event_enddate = events.event_enddate,
                    isEventActive = events.isEventActive,
                    employee_id = events.employee_id,
                    event_notes = events.event_notes,
                    clientNumber = events.clientNumber




                };
                db.GreenEvents.Add(newEvent);
                db.SaveChanges();
                logger.Info("New Event Added");
                return Ok("New Event Added");
            }
            catch (Exception)
            {
                logger.Error("Cant Upload Event");
                return BadRequest("Cant Add New Event");
            }


        }


        [HttpGet]
        [Route("api/GreenEvents/ReturnExpiredEventItems")]
        public IHttpActionResult ReturnExpiredEventItems()
        {
            try
            {
                // Get the current date
                var currentDate = DateTime.Now.Date;

                // Fetch the events that have already ended
                var expiredEvents = db.GreenEvents.Where(x => x.event_enddate < currentDate).ToList();

                foreach (var expiredEvent in expiredEvents)
                {
                    // Fetch all the inventory items for this event
                    var items = db.EventInventoryAllocation
                        .Where(x => x.eventSerialNum == expiredEvent.eventSerialNum)
                        .ToList();

                    foreach (var item in items)
                    {
                        // Find the item in the InventoryItems table
                        var inventoryItem = db.InventoryItems.FirstOrDefault(ii => ii.itemSerialNum == item.itemSerialNum);

                        if (inventoryItem != null)
                        {
                            // Add the allocated_quantity back to the inventory
                            inventoryItem.itemAmount += item.allocated_quantity;

                            // Remove the item from EventInventoryAllocation table
                            db.EventInventoryAllocation.Remove(item);
                        }
                    }

                    // Set the event to inactive
                    expiredEvent.isEventActive = false;
                }

                // Save the changes to the database
                db.SaveChanges();

                return Ok("Items from expired events have been returned to the inventory.");
            }
            catch (Exception ex)
            {
                logger.Error(ex, "Error returning items from expired events to inventory");
                return BadRequest("Can't return items from expired events to inventory");
            }
        }



        [HttpPost]
        [Route("api/GreenEvents/addwithinv")]
        public IHttpActionResult AddEventWithItems([FromBody] InventoryAllocationRequestDTO request)
        {
            if (!ModelState.IsValid)
            {
                Debug.WriteLine("ModelState Errors:");
                foreach (var modelState in ModelState.Values)
                {
                    foreach (var error in modelState.Errors)
                    {
                        Debug.WriteLine(error.ErrorMessage);
                    }
                }
                return BadRequest("Invalid model state");
            }
            Console.WriteLine("Entering AddEventWithItems function");
            try
            {
                var greenEvent = new GreenEvents
                {
                    eventSerialNum = request.eventSerialNum,
                    event_name = request.event_name,
                    event_address = request.event_address,
                    event_startdate = request.event_startdate,
                    event_enddate = request.event_enddate,
                    isEventActive = request.IsEventActive,
                    event_notes = request.event_notes,
                    employee_id = request.employee_id,
                    clientNumber = request.clientNumber
                };
                db.GreenEvents.Add(greenEvent);
                db.SaveChanges();


                int eventSerialNum1 = greenEvent.eventSerialNum;
                Console.WriteLine("GreenEvent added with eventSerialNum: " + eventSerialNum1);
                foreach (var allocation in request.ItemAllocations)
                {
                    var eventInventoryAllocation = new EventInventoryAllocation
                    {
                        eventSerialNum = eventSerialNum1,
                        itemSerialNum = allocation.itemSerialNum,
                        allocated_quantity = allocation.itemAmount,
                        event_start_date = request.event_startdate,
                        event_end_date = request.event_enddate
                    };

                    db.EventInventoryAllocation.Add(eventInventoryAllocation);
                    Console.WriteLine("EventInventoryAllocation created for itemSerialNum: " + allocation.itemSerialNum);
                    // Temporarily decrease itemAmount in InventoryItems
                    var inventoryItem = db.InventoryItems.Find(allocation.itemSerialNum);
                    if (inventoryItem != null)
                    {
                        inventoryItem.itemAmount -= allocation.itemAmount;

                        Console.WriteLine("Inventory item amount updated for itemSerialNum: " + allocation.itemSerialNum);
                    }

                }

                db.SaveChanges();
                return Ok("event with inventory added succesfully");

            }
            catch (Exception ex)
            {

                Console.WriteLine("Error: " + ex.Message);
                Console.WriteLine("Inner Exception: " + ex.InnerException?.Message);
                return BadRequest("Can't add event with inventory items"+ex.Message+ ex.InnerException?.Message);
            }


        }












        // PUT: api/GreenEvents/5
        [HttpPut]
        [Route("api/GreenEvents/put")]
        public IHttpActionResult Put([FromBody] GreenEventsDTO events)
        {
            igroup196_DbContextNew1 db = new igroup196_DbContextNew1();
            GreenEvents events1 = db.GreenEvents.Where(x => x.eventSerialNum == events.eventSerialNum).FirstOrDefault();
            try
            {
                if (events1 != null)
                {
                    events1.eventSerialNum = events.eventSerialNum;
                    events1.event_name = events.event_name;
                    events1.event_address = events.event_address;
                    events1.event_startdate = events.event_startdate;
                    events1.event_enddate = events.event_enddate;
                    events1.isEventActive = events.isEventActive;
                    events1.employee_id = events.employee_id;
                    events1.clientNumber = events.clientNumber;
                    events1.event_notes = events.event_notes;
                    db.SaveChanges();
                    logger.Info($"Event {events.eventSerialNum} Updated");
                    return Ok("Event Updated");
                }

                else
                {
                    logger.Error("Event search failure");
                    return BadRequest("Event Number Not Found");
                }
            }
            catch (Exception)
            {
                logger.Warn("Execption updating events");
                return BadRequest("cant Update Event");
            }







        }

        // DELETE: api/GreenEvents/5
        [HttpDelete]
        [Route("api/GreenEvents/delete")]
        public IHttpActionResult Delete([FromBody] GreenEventsDTO events)
        {
            igroup196_DbContextNew1 db = new igroup196_DbContextNew1();
            var eventToDelete = db.GreenEvents.FirstOrDefault(x => x.eventSerialNum == events.eventSerialNum);

            if (eventToDelete != null)
            {
                // Update or Remove EventInventoryAllocation associated with the event
                var eventInventoryItems = db.EventInventoryAllocation.Where(item => item.eventSerialNum == events.eventSerialNum);
                foreach (var item in eventInventoryItems)
                {
                    // choose to either remove the item or just remove the event reference 
                    // item.eventSerialNum = null; // Remove the reference to the event
                    db.EventInventoryAllocation.Remove(item); // Remove the item entirely
                }

                // Update the event reference in the GreenEvents table
                eventToDelete.employee_id = null;  // Update employee_id to null
                eventToDelete.clientNumber = null;  // Update customer_id to null

                db.GreenEvents.Remove(eventToDelete);
                db.SaveChanges();
                logger.Info($"Event {events.eventSerialNum} Deleted");
                return Ok("Event deleted");
            }
            else
            {
                logger.Error("Failure Deleting Event");
                return BadRequest("Event Not Found. Didn't Delete");
            }
        }

    }
}
