﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication2check.DTO
{
    public class InventoryAllocationRequestDTO
    {
        public int eventSerialNum { get; set; }
        public string event_name { get; set; }
        public string event_address { get; set; }
        public DateTime? event_startdate { get; set; }
        public DateTime? event_enddate { get; set; }
        public bool? IsEventActive { get; set; }
        public string event_notes { get; set; }
        public int? employee_id { get; set; }
        public int? clientNumber { get; set; }
        public List<ItemAllocationDTO> ItemAllocations { get; set; }
    }
}