﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication2check.DTO
{
    public class VehicleListDTO
    {
        public int licensePlateNum;
        public string vehicleType;
        public string vehicleColor;
        public string licenseType;
        public string vehicleOwnership;
        public string manufacturingYear;
    }
}