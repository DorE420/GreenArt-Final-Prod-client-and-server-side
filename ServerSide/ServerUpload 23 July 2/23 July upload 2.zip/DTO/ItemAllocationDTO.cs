﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication2check.DTO
{
    public class ItemAllocationDTO
    {
        public string itemName { get; set; }
        public int itemSerialNum { get; set; }
        public int? itemAmount { get; set; }
    }
}